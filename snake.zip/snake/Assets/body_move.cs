﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class body_move : MonoBehaviour {
	public body_move next;

	public void move(Vector3 _pos){
	
		Vector3 _pos_next = transform.position;
		transform.position = _pos;

		if (next != null) {
		
			next.move (_pos_next);
		
		}
	
	
	}

}
