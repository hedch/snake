﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class head_control : MonoBehaviour {


	private float speed = 18.0f;
	private float _Timer = 0f;

	enum dir_Head {up, down, left, right};
	private dir_Head _current_dir = dir_Head.up;
	private dir_Head _next_dir = dir_Head.up;

	public GameObject food;
	public GameObject body;

	private bool gameover=false;


	private body_move _first;
	private body_move _last;

	void Start () {

		create_food ();
		
	}
	
	// Update is called once per frame
	void Update () {
		if (!gameover) {
			
			turn ();
			move ();
		}
	}

	public void OnTriggerEnter(Collider other){
		if (other.tag.Equals ("boundary")) {

			gameover = true;
		}

		if (other.tag.Equals ("body")) {

			gameover = true;
		}

		if (other.tag.Equals ("food")) {
		
			Destroy (other.gameObject);
			grow ();
			create_food ();
		
		}
	
	
	
	}
	private void turn(){

		if (Input.GetKey (KeyCode.W )) {
			if (_current_dir == dir_Head.down) {
				_next_dir = dir_Head.down;
			} else {
				_next_dir = dir_Head.up;
			}
		}

		if (Input.GetKey (KeyCode.S )) {
			if (_current_dir == dir_Head.up) {
				_next_dir = dir_Head.up;
			} else {
				_next_dir = dir_Head.down;
			}
		}

		if (Input.GetKey (KeyCode.A )){
			if (_current_dir == dir_Head.right) {
				_next_dir = dir_Head.right;
			} else {
				_next_dir = dir_Head.left;
			}
		}

		if (Input.GetKey (KeyCode.D )) {
			if (_current_dir == dir_Head.left) {
				_next_dir = dir_Head.left;
			} else {
				_next_dir = dir_Head.right;
			}
		}

		switch (_next_dir) {
		case dir_Head.up:
			transform.forward = Vector3.forward;
			_current_dir = dir_Head.up;
			break;
		case dir_Head.down:
			transform.forward = Vector3.back;
			_current_dir = dir_Head.down;
			break;
		case dir_Head.left:
			transform.forward = Vector3.left;
			_current_dir = dir_Head.left;
			break;
		case dir_Head.right:
			transform.forward = Vector3.right;
			_current_dir = dir_Head.right;
			break;


		}


	}

	private void move(){

		_Timer += Time.deltaTime;
		if (_Timer >= 1 / speed) {
		
			Vector3 next_body_pos = transform.position;

			transform.Translate (Vector3.forward);
			_Timer = 0f;

		
			if (_first != null) {
			
				_first.move (next_body_pos);
			
			}
		
		}
	}

	public void create_food(){

		float x = Random.Range (-23.0f, 23.0f);
		float z = Random.Range (-23.0f, 23.0f);
	
		GameObject obj = Instantiate (food, new Vector3(x, 1.0f, z), Quaternion.identity) as GameObject;
	}


	public void grow(){

		GameObject obj = Instantiate (body, new Vector3(1.0f, 1000.0f, 1.0f), Quaternion.identity) as GameObject;
		body_move _cur = obj.GetComponent<body_move> ();

		if (_first == null) {
			_first = _cur;
		
		}

		if (_last != null) {
			_last.next = _cur;
		
		}
		_last = _cur;
	}

}
